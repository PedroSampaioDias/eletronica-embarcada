#ifndef CONSTANTES_H
#define	CONSTANTES_H

#ifdef	__cplusplus
extern "C" {
#endif

#define modo_manual    0x00
#define modo_ventoinha 0x01
#define modo_valvula   0x02
#define modo_reset     0x03

#ifdef	__cplusplus
}
#endif

#endif	/* CONSTANTES_H */

