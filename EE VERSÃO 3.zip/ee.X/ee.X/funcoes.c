#include <xc.h>
#include "mcc_generated_files/mcc.h"
#include "main.h"
#include "funcoes.h"

//------------------------------------------------------------------------------------
// Essa fun��o deve ser chamada para iniciar captura de dados de altura pelo ultrassom
//------------------------------------------------------------------------------------
void inicia_ultrasom(){             // < Fun��o responsavel por iniciar ultrasom
    //< A cada 100ms envia os dados
    static uint8_t j=0;             //< Auxiliar inicia em 0
    if(j==10){EnviaTx();}           //< Verifica se chegou em 10*10ms=100ms
    j = (j==10) ? 0 : (j+1);        //< Incrementa se for menor que 10, zera se for igual a 10
    
    Trigger_SetHigh();              // < Habilita o TRIGER
    TMR1_WriteTimer(0);             // < Zerar o timer para melhor precis�o
    __delay_us(12);                 // < Seta o timer pelo tempo necessario
    Trigger_SetLow();               // < Desabilita o TRIGER
}

//--------------------------------------------------------------------------------------
//-------- Fun��o que retorna a velocidade do som de acordo com a temperatura ----------
//--------------------------------------------------------------------------------------
uint16_t velocidade_som() {
    temperatura = (uint16_t)(ADC_GetConversion(Temp)/10);
    return relacao_som_temperatura[temperatura];
}

//--------------------------------------------------------------------------------------
//----------- Fun��o que retorna a media dos tempos recebidos do timer -----------------
//--------------------------------------------------------------------------------------
void media(uint16_t timer) {
    static uint8_t i=0;                     //< Indice do vetor
    static uint16_t tempo_recebido[4];      //< Inicia as variaveis de recebimento de tempo
    i = (i==3) ? 0 : (i+1);                 //< Verifica se o indice chegou ao valor maximo = 3 
                                            //<se n�o incrementa, se sim volta a zero
    tempo_recebido[i] = timer;              //< Atualiza vetor
    tempo_medio = (tempo_recebido[0] + tempo_recebido[1] + tempo_recebido[2] + tempo_recebido[3])/4;
}

//--------------------------------------------------------------------------------------
//-------------------------- Fun��o de retorno do gate TIMER1 --------------------------
//--------------------------------------------------------------------------------------
void posicao_bola_tubo() {
    media(TMR1_ReadTimer());
    altura_bola = (uint16_t)(((velocidade_som()/2000) * (tempo_medio)) );
    TMR1_WriteTimer(0);
    ultima_medicao = true;
}

//--------------------------------------------------------------------------------------
//----------------------------------- Fun��o do motor ----------------------------------
//--------------------------------------------------------------------------------------
void DRMotordePassos(){
    if(posicao_val_atual > posicao_val_futura){
        posicao_val_atual--;
        funcao_diminui_num_passos();
    }else if (posicao_val_atual < posicao_val_futura){
        posicao_val_atual++;
        funcao_aumento_num_passos();
    }
}

//--------------------------------------------------------------------------------------
//----------------- Fun��o para abertura do motor de passos ----------------------------
//--------------- ESSA FUN��O DIMINUI O NUMERO DE PASSOS ATUAIS ------------------------
//--------------------------------------------------------------------------------------
void funcao_diminui_num_passos(){
    if(npassos == 3){// Ultima posi��o SM3 e SM4 habilitados
        // Atualiza para primeira posi��o
        Passo1();
    }else if(npassos == 0){// Primeira posi��o SM1 e SM4 habilitados
        // Atualiza para segunda posi��o
        Passo2();
    }else if(npassos == 1){// Segunda posi��o SM1 e SM2 habilitados
        // Atualiza para terceira posi��o
        Passo3();
    }else if(npassos == 2){// Terceira posi��o SM2 e SM3 habilitados
        // Atualiza para quarta posi��o
        Passo4();
    }else{
        // Inicia no passo 1
        Passo1();
    }
    npassos++;
    npassos = npassos & 0b00000011;
}

//--------------------------------------------------------------------------------------
//------------------ Fun��o para fechamento do motor de passos -------------------------
//----------------- ESSA FUN��O AUMENTA O NUMERO DE PASSOS ATUAIS ----------------------
//--------------------------------------------------------------------------------------
void funcao_aumento_num_passos(){
    if(npassos == 1){// Segunda posi��o SM1 e SM2 habilitados
        // Atualiza para primeira posi��o
        Passo1();
    }else if(npassos == 2){// Terceira posi��o SM2 e SM3 habilitados
        // Atualiza para segunda posi��o
        Passo2();
    }else if(npassos == 3){// Ultima posi��o SM3 e SM4 habilitados
        // Atualiza para terceira posi��o
        Passo3();
    }else if(npassos == 0){// Primeira posi��o SM1 e SM4 habilitados
        // Atualiza para quarta posi��o
        Passo4();
    }else{
        // Inicia no passo 1
        Passo1();
    }
    if(npassos==0){npassos=4;}
    npassos--;
    npassos = npassos & 0b00000011;
}

//--------------------------------------------------------------------------------------
//------------------------------- Passos do motor --------------------------------------
//--------------------------------------------------------------------------------------
void Passo1(){
    SM1_SetHigh();  // Habilitado   SM1
    SM2_SetLow();   // Desabilitado SM2
    SM3_SetLow();   // Desabilitado SM3
    SM4_SetHigh();  // Habilitado   SM4
}

void Passo2(){
    SM1_SetHigh();   // Habilitado   SM1
    SM2_SetHigh();   // Habilitado   SM2
    SM3_SetLow();    // Desabilitado SM3
    SM4_SetLow();    // Desabilitado SM4
}

void Passo3(){
    SM1_SetLow();    // Desabilitado SM1
    SM2_SetHigh();   // Habilitado   SM2
    SM3_SetHigh();   // Habilitado   SM3
    SM4_SetLow();    // Desabilitado SM4
}

void Passo4(){
    SM1_SetLow();    // Desabilitado SM1
    SM2_SetLow();    // Desabilitado SM2
    SM3_SetHigh();   // Habilitado   SM3
    SM4_SetHigh();   // Habilitado   SM4
}

//--------------------------------------------------------------------------------------
//------------------------------- Recebimento de dados ---------------------------------
//--------------------------------------------------------------------------------------
void Dados_recebidos()
{
    dado_atual = true;
    uint8_t rxData = EUSART_Read();
    if(countRx < quadro_completo){
        RxBuffer[countRx] = rxData;
        countRx++;
        TMR4_WriteTimer(0);
    }else{
        Led_Toggle();
        countRx++;
        TMR4_WriteTimer(0);
    }
}

//--------------------------------------------------------------------------------------
//-------------- Essa fun��o processa os dados recebidos ap�s o tempo ------------------
//--------------------------------------------------------------------------------------
void ProcessaDados()
{
    if(!dado_atual){return;} //< Se tiver ocorrido o estouro do TIMER e o dado n�o for atual
    dado_atual = false;      //< Flag verificadora se o dado � atual
    modo = RxBuffer[0];     //< Guarda o modo
    if(countRx == quadro_completo){
        Set_altura.bmsb = RxBuffer[1];
        Set_altura.blsb = RxBuffer[2];
        Set_valvula.bmsb = RxBuffer[3];
        Set_valvula.blsb = RxBuffer[4];
        Set_ciclo.bmsb = RxBuffer[5];
        Set_ciclo.blsb = RxBuffer[6];
    }
    selecao_do_modo();
    countRx = 0;            //< Zera contador de buffer
}

//--------------------------------------------------------------------------------------
//----------------- Seleciona o modo � coloca os devidos comandos ----------------------
//--------------------------------------------------------------------------------------
void selecao_do_modo(){
    switch(modo){
        // Comando manual, utiliza o valor do set valvula
        case COMANDO_MANUAL:
            if(Set_ciclo.Dado > 1023){Set_ciclo.Dado = 1023;}
            // Coloca a ventoinha na posi��o desejada ao inves de fazer o controle
            EPWM1_LoadDutyValue(Set_ciclo.Dado);
            if(Set_valvula.Dado > 420){Set_valvula.Dado = 420;}
            // Coloca a valvula na posi��o desejada ao inves de fazer o controle
            posicao_val_futura = Set_valvula.Dado;
            break;
        case COMANDO_VENTOINHA:
            if(Set_valvula.Dado > 420){Set_valvula.Dado = 420;}
            // Coloca a valvula na posi��o desejada ao inves de fazer o controle
            posicao_val_futura = Set_valvula.Dado;
            altura_desejada = Set_altura.Dado;
            break;
        case COMANDO_VALVULA:
            if(Set_ciclo.Dado > 1023){Set_ciclo.Dado = 1023;}
            // Coloca a ventoinha na posi��o desejada ao inves de fazer o controle
            EPWM1_LoadDutyValue(Set_ciclo.Dado);
            altura_desejada = Set_altura.Dado;
            break;
        case COMANDO_RESET:
            RESET();
            break;
        default:
            break;
    }
}

//--------------------------------------------------------------------------------------
//---------------------------------- Envio pela UART -----------------------------------
//--------------------------------------------------------------------------------------
void EnviaTx(){
    dados_de_envio[0]= modo;
    dados_de_envio[1]= Set_altura.bmsb;
    dados_de_envio[2]= Set_altura.blsb;
    dados_de_envio[3]=(altura_bola & 0xFF00) >> 8;
    dados_de_envio[4]=altura_bola & 0x00FF;
    dados_de_envio[5]=(tempo_medio & 0xFF00) >> 8;
    dados_de_envio[6]=tempo_medio & 0x00FF;
    dados_de_envio[7]=(temperatura & 0xFF00) >> 8;
    dados_de_envio[8]=temperatura & 0x00FF;
    dados_de_envio[9]=Set_valvula.bmsb;
    dados_de_envio[10]=Set_valvula.blsb;
    dados_de_envio[11]=(posicao_val_atual & 0xFF00) >> 8;
    dados_de_envio[12]=posicao_val_atual & 0x00FF;
    dados_de_envio[13]=(ciclo_util & 0xFF00) >> 8;
    dados_de_envio[14]=ciclo_util & 0x00FF;
    for(uint8_t i=0; i<15; i++){
        EUSART_Write(dados_de_envio[i]);      //< Transmite os 15 bytes do buffer de transmiss�o
    }
    EUSART_Write('\r');
    EUSART_Write('\n');

}

//--------------------------------------------------------------------------------------
//------------------------ Controlador dos propositos em PID ---------------------------
//--------------------------------------------------------------------------------------
void Comando_PIeD(){
    switch(modo){
        // No modo ventoinha o controle sera dado apenas pela ventoinha e a valvula ficara em posi��o fixa
        case COMANDO_VENTOINHA:
            modo_ventoinha();
            break;
        // No modo valvula o controle sera dado apenas pela valvula e a ventoinha ficara em posi��o fixa
        case COMANDO_VALVULA:
            modo_valvula();
            break;
        default:
            break;
    }
    ultima_medicao = false;
}

//--------------------------------------------------------------------------------------
//------------------------------ CONTROLADORES -----------------------------------------
//--------------------------------------------------------------------------------------
void modo_ventoinha(){
    erro_atual = (int) (Set_altura.Dado - altura_bola);
    if(erro_atual >15 || erro_atual < -15){
        integrativo += (ki_ventoinha*variacao_tempo*erro_atual);
        
        // Satura��es do integrativo
        if (integrativo > 100) integrativo = 100;
        else if (integrativo < -10) integrativo = -10;
        
        derivativo = kd_ventoinha*(erro_atual - erro_anterior)/variacao_tempo;
        
        soma_PID = (uint16_t) (integrativo + kp_ventoinha * erro_atual + derivativo + soma_PID);
        
        // Atribui��o dos valores PID
        if(soma_PID > 6230){
            ciclo_util = 1023;}
        else if(soma_PID <0) {
            ciclo_util= 400;
        }else{
            ciclo_util = ((uint16_t)soma_PID/10) + 400;}
        
        // Atualiza��es dos valores preparadores
        if (soma_PID>6230){
            soma_PID = 6230;
        } else if (soma_PID < -800){
            soma_PID = -800;
        }
        
        EPWM1_LoadDutyValue(ciclo_util); //mandando o valor apos o controle
        erro_anterior = erro_atual;     //error atual vira o error passado
    }
}

void modo_valvula(){
    erro_atual = (int) (Set_altura.Dado - altura_bola);
    if(erro_atual >15 || erro_atual < -15){
        integrativo += (ki_valvula*variacao_tempo*erro_atual);
        
        // Satura��es do integrativo
        if (integrativo > 100) integrativo = 100;
        else if (integrativo < -10) integrativo = -10;
        
        derivativo = kd_valvula*(erro_atual - erro_anterior)/variacao_tempo;
        
        soma_PID = (uint16_t) (integrativo + kp_valvula * erro_atual + derivativo + soma_PID);
        
        // Atribui��o dos valores PID
        if(soma_PID > 420){
            posicao_val_futura = 420;}
        else if(soma_PID <0) {
            posicao_val_futura= 0;
        }else{
            posicao_val_futura = ((uint16_t)soma_PID/30);}
        
        // Atualiza��es dos valores preparadores
        if (soma_PID>6230){
            soma_PID = 6230;
        } else if (soma_PID < -800){
            soma_PID = -800;
        }
        
        erro_anterior = erro_atual;     //error atual vira o error passado
    }
}
 