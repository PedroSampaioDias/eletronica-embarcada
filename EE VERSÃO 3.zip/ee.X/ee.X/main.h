/* 
 * File:   main.h
 * Author: pedro
 *
 * Created on February 13, 2025, 5:27 PM
 */

#ifndef MAIN_H
#define	MAIN_H

#ifdef	__cplusplus
extern "C" {
#endif
#define  numero_maximo_de_passos 420
#define  quadro_completo         7
#define  COMANDO_MANUAL          0x00
#define  COMANDO_VENTOINHA       0x01
#define  COMANDO_VALVULA         0x02
#define  COMANDO_RESET           0x03
    
__eeprom uint16_t relacao_som_temperatura[51] = {
    33145, 33206, 33266, 33327, 33387, 33447, 33507, 33567, 33627, 33687,
    33746, 33806, 33865, 33925, 33984, 34043, 34102, 34161, 34220, 34278,
    34337, 34396, 34454, 34512, 34570, 34629, 34687, 34745, 34802, 34860,
    34918, 34975, 35033, 35090, 35147, 35205, 35262, 35319, 35375, 35432,
    35489, 35546, 35602, 35659, 35715, 35771, 35827, 35883, 35939, 35995,
    36051
};

union{
    uint16_t Dado;
    struct{
        uint8_t blsb;
        uint8_t bmsb;
    };
}Set_altura,Set_valvula,Set_ciclo;

uint16_t tempo_s;

int24_t erro_atual;

int24_t erro_anterior;

int24_t ciclo_util_pre;

int24_t valvula_pre;

int24_t valvula;

int24_t integrativo = 0;

int24_t derivativo = 0;

int24_t soma_PID;

uint16_t variacao_tempo;

uint16_t ciclo_util;

uint8_t  RxBuffer[7];

uint8_t ki_ventoinha;

uint8_t kd_ventoinha;

uint8_t kp_ventoinha;

uint8_t ki_valvula;

uint8_t kd_valvula;

uint8_t kp_valvula;

uint16_t tempo_medio = 0;

uint16_t altura_bola = 0;

uint16_t posicao_val_atual = 0;

uint16_t altura_desejada;

uint16_t temperatura;

uint16_t posicao_val_futura = 0;

uint8_t  npassos = 0;

uint8_t dados_de_envio[15];

uint8_t modo;

bool     dado_atual = false;       // Verifica se o dado � atual

bool     ultima_medicao = false;   // Verifica se os dados est�o atualizados

uint8_t  countRx = 0;



#ifdef	__cplusplus
}
#endif

#endif	/* MAIN_H */

