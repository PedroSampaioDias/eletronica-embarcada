#include <xc.h>
#include "mcc_generated_files/mcc.h"
#include "main.h"
#include "funcoes.h"

//------------------------------------------------------------------------------------
// Essa fun��o deve ser chamada para iniciar captura de dados de altura pelo ultrassom
//------------------------------------------------------------------------------------
void inicia_ultrasom(){             // Fun��o responsavel por iniciar ultrasom
    // A cada 100ms envia os dados
    static uint8_t j=0;             // Auxiliar inicia em 0
    if(j==10){EnviaTx();}           // Verifica se chegou em 10*10ms=100ms
    j = (j==10) ? 0 : (j+1);        // Incrementa se for menor que 10, zera se for igual a 10
    
    Trigger_SetHigh();              // Habilita o TRIGER
    TMR1_WriteTimer(0);             // Zerar o timer para melhor precis�o
    __delay_us(12);                 // Seta o timer pelo tempo necessario
    Trigger_SetLow();               // Desabilita o TRIGER
}

//--------------------------------------------------------------------------------------
//-------- Fun��o que retorna a velocidade do som de acordo com a temperatura ----------
//--------------------------------------------------------------------------------------
uint16_t velocidade_som() {
    // Obtém a temperatura medida pelo sensor do microcontrolador
    temperatura = (uint16_t)(ADC_GetConversion(Temp) / 10);

    // Retorna a velocidade do som correspondente à temperatura lida
    return relacao_som_temperatura[temperatura];
}


//--------------------------------------------------------------------------------------
//----------- Fun��o que retorna a media dos tempos recebidos do timer -----------------
//--------------------------------------------------------------------------------------
void media(uint16_t timer) {
    static uint8_t i=0;                     // Indice do vetor
    static uint16_t tempo_recebido[2];      // Inicia as variaveis de recebimento de tempo
    i = (i+1) % 2; 
                                            // Se n�o incrementa, se sim volta a zero
    tempo_recebido[i] = timer;              // Atualiza vetor
    tempo_medio = (tempo_recebido[0] + tempo_recebido[1])/2;
}

//--------------------------------------------------------------------------------------
//-------------------------- Function de retorno do gate TIMER1 --------------------------
//--------------------------------------------------------------------------------------
void posicao_bola_tubo() {
    // Calcula a média dos tempos de medição do sensor ultrassônico
    media(TMR1_ReadTimer());

    // Calcula a altura da bola no tubo:
    // - velocidade_som() retorna a velocidade do som ajustada pela temperatura
    // - tempo_medio contém o tempo medido do sensor ultrassônico
    altura_bola = (uint16_t)(((uint16_t)((velocidade_som() / 2000) * (tempo_medio))));

    // Chama o controle PID/PI para ajustar a válvula ou a ventoinha conforme necessário
    Comando_PIeD();

    // Atualiza a temperatura lida pelo sensor do microcontrolador
    temperatura = (uint16_t)(ADC_GetConversion(Temp) / 10) * 10;

    // Reseta o temporizador para próxima medição
    TMR1_WriteTimer(0);
}


//--------------------------------------------------------------------------------------
//----------------------------------- Fun��o do motor ----------------------------------
//--------------------------------------------------------------------------------------
void DRMotordePassos(){
    // Verifica maximos
    if(posicao_val_futura > numero_maximo_de_passos){
        posicao_val_futura = numero_maximo_de_passos;}
    if(ciclo_util_futuro > maximo_pwm){
        ciclo_util_futuro = maximo_pwm;}
    
    if(posicao_val_atual > posicao_val_futura){
        posicao_val_atual--;
        funcao_diminui_num_passos();
    }else if (posicao_val_atual < posicao_val_futura){
        posicao_val_atual++;
        funcao_aumento_num_passos();
    }
    
    //Comando_PIeD();
    
        // Incrementa a ventoinha de modo semelhante
//    if(ciclo_util > ciclo_util_futuro){        // Caso o valor atual seja maior que o desejado
//        ciclo_util = ciclo_util - 2;      // Decrementa a posi��o
//    }else if(ciclo_util < ciclo_util_futuro){  // Caso o valor atual seja menor que o desejado
//        ciclo_util = ciclo_util + 2; }    // Incrementa o valor atual
//    
//    // Se a diferen�a entre do PWM for apenas 1 unidade ent�o igualam as duas
//    if(ciclo_util == ciclo_util_futuro + 1 || ciclo_util == ciclo_util_futuro - 1){
//        ciclo_util = ciclo_util_futuro;}
//    
//    EPWM1_LoadDutyValue(ciclo_util);
}

//--------------------------------------------------------------------------------------
//----------------- Function para abertura do motor de passos ----------------------------
//--------------- ESSA Function DIMINUI O NUMERO DE PASSOS ATUAIS ------------------------
//--------------------------------------------------------------------------------------
void funcao_diminui_num_passos(){
    if(npassos == 3){// Ultima posi��o SM3 e SM4 habilitados
        // Atualiza para primeira posi��o
        Passo1();
    }else if(npassos == 0){// Primeira posi��o SM1 e SM4 habilitados
        // Atualiza para segunda posi��o
        Passo2();
    }else if(npassos == 1){// Segunda posi��o SM1 e SM2 habilitados
        // Atualiza para terceira posi��o
        Passo3();
    }else if(npassos == 2){// Terceira posi��o SM2 e SM3 habilitados
        // Atualiza para quarta posi��o
        Passo4();
    }else{
        // Inicia no passo 1
        Passo1();
    }
    npassos++;
    npassos = npassos & 0b00000011;
}

//--------------------------------------------------------------------------------------
//------------------ Fun��o para fechamento do motor de passos -------------------------
//----------------- ESSA FUN��O AUMENTA O NUMERO DE PASSOS ATUAIS ----------------------
//--------------------------------------------------------------------------------------
void funcao_aumento_num_passos(){
    if(npassos == 1){// Segunda posi��o SM1 e SM2 habilitados
        // Atualiza para primeira posi��o
        Passo1();
    }else if(npassos == 2){// Terceira posi��o SM2 e SM3 habilitados
        // Atualiza para segunda posi��o
        Passo2();
    }else if(npassos == 3){// Ultima posi��o SM3 e SM4 habilitados
        // Atualiza para terceira posi��o
        Passo3();
    }else if(npassos == 0){// Primeira posi��o SM1 e SM4 habilitados
        // Atualiza para quarta posi��o
        Passo4();
    }else{
        // Inicia no passo 1
        Passo1();
    }
    if(npassos==0){npassos=4;}
    npassos--;
    npassos = npassos & 0b00000011;
}

//--------------------------------------------------------------------------------------
//------------------------------- Passos do motor --------------------------------------
//--------------------------------------------------------------------------------------
void Passo1(){
    SM1_SetHigh();  // Habilitado   SM1
    SM2_SetLow();   // Desabilitado SM2
    SM3_SetLow();   // Desabilitado SM3
    SM4_SetHigh();  // Habilitado   SM4
}

void Passo2(){
    SM1_SetHigh();   // Habilitado   SM1
    SM2_SetHigh();   // Habilitado   SM2
    SM3_SetLow();    // Desabilitado SM3
    SM4_SetLow();    // Desabilitado SM4
}

void Passo3(){
    SM1_SetLow();    // Desabilitado SM1
    SM2_SetHigh();   // Habilitado   SM2
    SM3_SetHigh();   // Habilitado   SM3
    SM4_SetLow();    // Desabilitado SM4
}

void Passo4(){
    SM1_SetLow();    // Desabilitado SM1
    SM2_SetLow();    // Desabilitado SM2
    SM3_SetHigh();   // Habilitado   SM3
    SM4_SetHigh();   // Habilitado   SM4
}

//--------------------------------------------------------------------------------------
//------------------------------- Recebimento de dados ---------------------------------
//--------------------------------------------------------------------------------------
void Dados_recebidos()
{
    dado_atual = true;                  // Flag para o controle de envio de dados
    uint8_t rxData = EUSART_Read();     // Variavel guardando o valor recebido
    if(countRx < quadro_completo_ABCD){ // Guarda o valor enquanto n�o chegar no maximo
        RxBuffer[countRx] = rxData;
        countRx++;
        TMR4_WriteTimer(0);
    }else{
        countRx++;                      // Se passar do maximo s� incrementa contador
        TMR4_WriteTimer(0);
    }
}

//--------------------------------------------------------------------------------------
//-------------- Essa fun��o processa os dados recebidos ap�s o tempo ------------------
//--------------------------------------------------------------------------------------
void ProcessaDados()
{
    if(!dado_atual){return;} //< Se tiver ocorrido o estouro do TIMER e o dado n�o for atual
    dado_atual = false;      //< Flag verificadora se o dado � atual
    modo = RxBuffer[0];     //< Guarda o modo
    if(countRx == quadro_completo_ABCD){
        switch(modo){
            // Atribuir os valores as variaveis de cada controle
            case COMANDO_MANUAL:
                Set_valvula.bmsb = RxBuffer[1];
                Set_valvula.blsb = RxBuffer[2];
                Set_ciclo.bmsb   = RxBuffer[3];
                Set_ciclo.blsb   = RxBuffer[4];
                break;
            case COMANDO_VENTOINHA:
                Set_altura.bmsb  = RxBuffer[1];
                Set_altura.blsb  = RxBuffer[2];
                Set_valvula.bmsb = RxBuffer[3];
                Set_valvula.blsb = RxBuffer[4];
                break;
            case COMANDO_VALVULA:
                Set_altura.bmsb = RxBuffer[1];
                Set_altura.blsb = RxBuffer[2];
                Set_ciclo.bmsb  = RxBuffer[3];
                Set_ciclo.blsb  = RxBuffer[4];
                break;
            default:
                break;
        }
        selecao_do_modo();
    }else if(modo == COMANDO_RESET){
        RESET();
    }
    countRx = 0;            //< Zera contador de buffer
}

//--------------------------------------------------------------------------------------
//----------------- Seleciona o modo � coloca os devidos comandos ----------------------
//--------------------------------------------------------------------------------------
void selecao_do_modo(){
    switch(modo){
        // Comando manual, utiliza o valor do set valvula
        case COMANDO_MANUAL:
            if(Set_ciclo.Dado > 1023){Set_ciclo.Dado = 1023;}
            // Coloca a ventoinha na posi��o desejada ao inves de fazer o controle
            ciclo_util_futuro = Set_ciclo.Dado;
            EPWM1_LoadDutyValue(ciclo_util_futuro);
            if(Set_valvula.Dado > 460){Set_valvula.Dado = 460;}
            // Coloca a valvula na posi��o desejada ao inves de fazer o controle
            posicao_val_futura = Set_valvula.Dado;
            break;
        case COMANDO_VENTOINHA:
            if(Set_valvula.Dado > 460){Set_valvula.Dado = 460;}
            // Coloca a valvula na posi��o desejada ao inves de fazer o controle
            posicao_val_futura = Set_valvula.Dado;
            erro_atual = 0;
            soma_PID = 0;
            integrativo = 0;
            proporcional = 0;
            derivativo = 0;
            break;
        case COMANDO_VALVULA:
            if(Set_ciclo.Dado > 1023){Set_ciclo.Dado = 1023;}
            // Coloca a ventoinha na posi��o desejada ao inves de fazer o controle
            ciclo_util_futuro = Set_ciclo.Dado;
            EPWM1_LoadDutyValue(ciclo_util_futuro);
            erro_atual = 0;
            soma_PID = 0;
            integrativo = 0;
            proporcional = 0;
            derivativo = 0;
            break;
        default:
            break;
    }
}

//--------------------------------------------------------------------------------------
//---------------------------------- Envio pela UART -----------------------------------
//--------------------------------------------------------------------------------------
void EnviaTx(){
/
    EUSART_Write((uint16_t)Set_altura.bmsb);                      // Envia o setpoint de altura
    EUSART_Write((uint16_t)Set_altura.blsb);                      // ....
    EUSART_Write(((uint16_t)(altura_bola & 0xFF00)) >> 8);          // Envia a ultima medi��o de altura
    EUSART_Write(altura_bola & 0x00FF);
    EUSART_Write((erro_atual & 0xFF0000) >> 16);
    EUSART_Write((erro_atual & 0x00FF00) >> 8);
    EUSART_Write(erro_atual & 0x0000FF);
    EUSART_Write((integrativo & 0xFF0000) >> 16);
    EUSART_Write((integrativo & 0x00FF00) >> 8);
    EUSART_Write(integrativo & 0x0000FF);
    EUSART_Write((proporcional & 0xFF0000) >> 16);
    EUSART_Write((proporcional & 0x00FF00) >> 8);
    EUSART_Write(proporcional & 0x0000FF);
    EUSART_Write((soma_PID & 0xFF0000) >> 16);
    EUSART_Write((soma_PID & 0x00FF00) >> 8);
    EUSART_Write(soma_PID & 0x0000FF);
    EUSART_Write((posicao_val_futura & 0xFF00) >> 8);
    EUSART_Write(posicao_val_futura & 0x00FF);
    EUSART_Write((posicao_val_atual & 0xFF00) >> 8);
    EUSART_Write(posicao_val_atual & 0x00FF);
    EUSART_Write((ciclo_util_futuro & 0xFF00) >> 8);
    EUSART_Write(ciclo_util_futuro & 0x00FF);
    EUSART_Write('\r');
    EUSART_Write('\n');

}

//--------------------------------------------------------------------------------------
//------------------------ Controlador dos propositos em PID ---------------------------
//--------------------------------------------------------------------------------------
void Comando_PIeD(){
    switch(modo){
        // No modo ventoinha o controle sera dado apenas pela ventoinha e a valvula ficara em posi��o fixa
        case COMANDO_VENTOINHA:
            modo_ventoinha();
            break;
        // No modo valvula o controle sera dado apenas pela valvula e a ventoinha ficara em posi��o fixa
        case COMANDO_VALVULA:
            modo_valvula();
            break;
        default:
            break;
    }
}

//--------------------------------------------------------------------------------------
//------------------------------ CONTROLADORES -----------------------------------------
//--------------------------------------------------------------------------------------
// Converte o valor x do intervalo [in_min, in_max] para [out_min, out_max]
int24_t map_value(int32_t x, int32_t in_min, int32_t in_max, int32_t out_min, int32_t out_max) {
    return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}

void modo_ventoinha(){
    // Calcula o erro entre a altura desejada e a altura real da bola
    erro_atual = (int24_t)(((int24_t)Set_altura.Dado) - ((int24_t)(altura_bola)));

    // Cálculo do termo integral (acumula erro ao longo do tempo)
    integrativo += (int24_t)(((ki_ventoinha * erro_atual) / 1000));

    // Cálculo do termo proporcional (ajusta rapidamente de acordo com o erro)
    proporcional = ((((int24_t)kp_ventoinha / 1000)) * erro_atual);

    // Cálculo do termo derivativo (responde às mudanças bruscas do erro)
    derivativo = (int24_t)(kd_ventoinha * (erro_atual - erro_anterior)) / 1000;

    // Soma dos três termos para formar a ação de controle PID
    soma_PID = proporcional + integrativo + derivativo;

    // Saturação da saída para evitar valores excessivos
    if (soma_PID < 0) soma_PID = 0;
    if (soma_PID > 42000) soma_PID = 42000;

    // Mapeia a saída para um valor de PWM adequado à ventoinha
    ciclo_util_futuro = (int16_t)map_value(soma_PID, 0, 42000, 600, 1023);

    // Aplica o valor de PWM na ventoinha
    EPWM1_LoadDutyValue(ciclo_util_futuro);

    // Atualiza o erro anterior para a próxima iteração
    erro_anterior = erro_atual;
}


void modo_valvula(){
    // Calcula o erro entre a altura desejada e a altura medida
    erro_atual = (int24_t)(((int24_t)Set_altura.Dado) - ((int24_t)(altura_bola)));

    // Cálculo do termo integral (acumula erro ao longo do tempo)
    integrativo += ((ki_valvula / 1000) * (erro_atual));

    // Limitação do termo integral para evitar crescimento excessivo (Windup)
    if (integrativo > 350) { integrativo = 350; }   // Limite superior
    if (integrativo < -350) { integrativo = -350; } // Limite inferior

    // Cálculo do termo proporcional (responde diretamente ao erro)
    proporcional = ((kp_valvula / 1000) * erro_atual);

    // Soma dos termos proporcional e integral para formar a ação de controle
    soma_PID = proporcional + integrativo;

    // Saturação da saída para evitar valores fora dos limites da válvula
    if (soma_PID < 0) soma_PID = 0;          // Garante que não haja valores negativos
    if (soma_PID > 42000) soma_PID = 42000;  // Garante que não ultrapasse o máximo permitido

    // Mapeamento do valor do PID para os limites físicos da válvula
    posicao_val_futura = (int16_t)map_value(soma_PID, 0, 42000, 460, 0);

    // Atualiza o erro anterior para a próxima iteração
    erro_anterior = erro_atual;
}
