/* 
 * File:                funcoes.h  
 * Author:              Herbert Tavares, Julio Cesar Carvalhes, Pedro Sampaio, Rafael Brasileiro
 * Comments:            -- // --
 */

#ifndef FUNCOES_H
#define	FUNCOES_H

#include <xc.h> // include processor files - each processor file is guarded.  

//------------------------------------------------------------------------------------------------------------------------------------------------------
/**
 * @brief   realiza a mudan�a dos passos no sentido original
 * @param   dutyValue
 * @return  ---
 */
void funcao_aumento_num_passos();
//------------------------------------------------------------------------------------------------------------------------------------------------------
/**
 * @brief   realiza a mudan�a dos passos no sentido contrario ao original
 * @param   ---
 * @return  ---
 */
void funcao_diminui_num_passos();
//------------------------------------------------------------------------------------------------------------------------------------------------------
/**
 * @brief   Primeiro passo do motor
 * @param   posicaoAtual, posicaoDesejada
 * @return  ---
 */
void Passo1();
//------------------------------------------------------------------------------------------------------------------------------------------------------
/**
 * @brief   Segundo passo do motor
 * @param   ---
 * @return  ---
 */
void Passo2();
//------------------------------------------------------------------------------------------------------------------------------------------------------
/**
 * @brief   Terceiro passo do motor
 * @param   ---
 * @return  ---
 */
void Passo3();
//------------------------------------------------------------------------------------------------------------------------------------------------------
/**
 * @brief   Quarto passo do motor
 * @param   ---
 * @return  ---
 */
void Passo4();
//------------------------------------------------------------------------------------------------------------------------------------------------------
/**
 * @brief   Atualiza os passos do motor
 * @param   ---
 * @return  ---
 */
void DRMotordePassos();
//------------------------------------------------------------------------------------------------------------------------------------------------------
/**
 * @brief   Calculo da posi��o da altura
 * @param   ---
 * @return  ---
 */
void posicao_bola_tubo();
//------------------------------------------------------------------------------------------------------------------------------------------------------
/**
 * @brief   Calcula a media do sistema
 * @param   ---
 * @return  ---
 */
void media(uint16_t timer);
//------------------------------------------------------------------------------------------------------------------------------------------------------
/**
 * @brief  Calcular altura 
 * @param
 * @return
 */
void medir_altura();
//------------------------------------------------------------------------------------------------------------------------------------------------------
/**
 * @brief Aquisi  o da Posi  o da Bola no Tubo
 * @param   ---
 * @return  ---
 */
//------------------------------------------------------------------------------------------------------------------------------------------------------
void Posicao_Bola_Tubo(void);

/**
 * @brief Carrega o buffer de envio (Tx) com as informa  es
 */
//------------------------------------------------------------------------------------------------------------------------------------------------------
void EnviaTx(void);


/**
 * @brief Calcula a m dia das 4  ltimas medi  es de dist ncia
 * @param Time
 * @return M dia calculada
 */
//------------------------------------------------------------------------------------------------------------------------------------------------------
uint16_t Media(uint16_t Time);

/**
 * @brief Calcula a m dia das 4  ltimas medi  es de dist ncia
 * @param Time
 * @return M dia calculada
 */
//------------------------------------------------------------------------------------------------------------------------------------------------------
/**
 * @brief Seleciona o modo de operação do sistema e configura os parâmetros correspondentes.
 * @param ---
 * @return ---
 */
void selecao_do_modo(void);

/**
 * @brief Controla a ventoinha para ajustar a altura da bola usando um controlador PID.
 * @param ---
 * @return ---
 */
void modo_ventoinha(void);

/**
 * @brief Lê os dados recebidos pela UART e armazena no buffer para processamento.
 * @param ---
 * @return ---
 */
void Dados_recebidos(void);

/**
 * @brief Controla a válvula para ajustar a posição da bola usando um controlador PI.
 * @param ---
 * @return ---
 */
void modo_valvula(void);

/**
 * @brief Executa o controle PI ou PID, dependendo do modo de operação selecionado.
 * @param ---
 * @return ---
 */
void Comando_PIeD(void);

/**
 * @brief Inicia a medição da altura da bola utilizando um sensor ultrassônico.
 * @param ---
 * @return ---
 */
void inicia_ultrasom(void);

/**
 * @brief Processa os dados recebidos via UART e atualiza os parâmetros do sistema.
 * @param ---
 * @return ---
 */
void ProcessaDados(void);


#endif	/* FUNCOES_H */