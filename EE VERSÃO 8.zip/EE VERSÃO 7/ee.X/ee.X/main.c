#include "mcc_generated_files/mcc.h"
#include "funcoes.h"
#include "main.h"

void main(void) {
    // Inicializa o sistema
    SYSTEM_Initialize();
    
    // Habilita interrup��es globais
    INTERRUPT_GlobalInterruptEnable();

    // Habilita interrup��es perifericas
    INTERRUPT_PeripheralInterruptEnable();
    
    // Recebimento de dados interrup��o UART
    // EUSART_SetRxInterruptHandler(Dados_recebidos);
    
    // Interrup��o do timeour 40 ms sem receber dados
    TMR4_SetInterruptHandler(ProcessaDados);
    
    // Interrup��o para medi��o
    TMR0_SetInterruptHandler(inicia_ultrasom);
    
    // Interrup��o do GATE
    TMR1_SetGateInterruptHandler(posicao_bola_tubo);
    
    // Interrup��o motor de passos
    TMR6_SetInterruptHandler(DRMotordePassos);
   
    // Calibra��o da valvula
    while(!CMP1_GetOutputStatus()){ // Espera chegada no fim de curso
        funcao_diminui_num_passos();
        __delay_ms(4);
    }
    posicao_val_atual = 0;          // Zera a posi��o no fim de curso

    while (1)
    {
        // Atualiza o estado do LED:
        // Se a saída do comparador CMP1 estiver em nível baixo (0), o LED acende (1).
        // Se estiver em nível alto (1), o LED apaga (0).
        Led_LAT = !CMP1_GetOutputStatus();

        // Verifica se há dados disponíveis para leitura na UART.
        if (EUSART_is_rx_ready())
        {
            Dados_recebidos(); // Chama a função que processa os dados recebidos via UART.
        }
    }
}