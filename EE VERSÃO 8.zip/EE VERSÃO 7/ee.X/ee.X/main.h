/* 
 * File:   main.h
 * Author: Herbert, Julio, Pedro e Rafael
 *
 * Created on February 13, 2025, 5:27 PM
 */

#ifndef MAIN_H
#define	MAIN_H

#ifdef	__cplusplus
extern "C" {
#endif
#define numero_maximo_de_passos 460   // Número máximo de passos da válvula (limite físico)
#define maximo_pwm              1023  // Valor máximo do ciclo de trabalho do PWM (10 bits)
#define quadro_completo_ABCD    5     // Número total de bytes esperados na comunicação UART
#define COMANDO_MANUAL          0x00  // Modo de operação: Controle manual (sem PID)
#define COMANDO_VENTOINHA       0x01  // Modo de operação: Controle pela ventoinha (PID ativo)
#define COMANDO_VALVULA         0x02  // Modo de operação: Controle pela válvula (PI ativo)
#define COMANDO_RESET           0x03  // Comando para resetar o sistema

// Tabela armazenada na memória EEPROM para obter a velocidade do som em função da temperatura.
// Cada índice representa um valor de temperatura em °C e retorna a velocidade do som correspondente.
__eeprom uint16_t relacao_som_temperatura[51] = {
    33145, 33206, 33266, 33327, 33387, 33447, 33507, 33567, 33627, 33687,
    33746, 33806, 33865, 33925, 33984, 34043, 34102, 34161, 34220, 34278,
    34337, 34396, 34454, 34512, 34570, 34629, 34687, 34745, 34802, 34860,
    34918, 34975, 35033, 35090, 35147, 35205, 35262, 35319, 35375, 35432,
    35489, 35546, 35602, 35659, 35715, 35771, 35827, 35883, 35939, 35995,
    36051
};

// Union utilizada para manipulação de dados de 16 bits, permitindo acesso direto a MSB e LSB.
// Usada para transmissão e recepção de valores pela UART.
union {
    uint16_t Dado;  // Valor total (16 bits)
    struct {
        uint8_t blsb;  // Byte menos significativo (LSB)
        uint8_t bmsb;  // Byte mais significativo (MSB)
    };
} Set_altura, Set_valvula, Set_ciclo;  


int16_t Set_alturah;         // Parte superior do setpoint da altura (provavelmente MSB)
int16_t Set_altural;         // Parte inferior do setpoint da altura (provavelmente LSB)
int16_t Set_altura_total;    // Valor completo do setpoint da altura

int16_t tempo_s;             // Tempo de amostragem ou variável auxiliar de tempo
int24_t erro_atual = 0;      // Diferença entre a altura desejada e a altura da bola (erro de controle)
int24_t erro_anterior = 0;   // Armazena o erro da iteração anterior para cálculo do termo derivativo

int24_t ciclo_util_pre;   // Variável auxiliar para armazenar ciclo de trabalho anterior do PWM
int24_t valvula_pre;      // Armazena a posição anterior da válvula
int24_t valvula;          // Posição atual da válvula

int24_t integrativo = 0;  // Acumulador do termo integral do controlador
int24_t proporcional = 0; // Componente proporcional do controle PID
int24_t derivativo = 0;   // Componente derivativo do controle PID
int24_t soma_PID = 0;     // Soma total dos termos P, I (e D se aplicável)

int16_t variacao_tempo;  // Tempo entre iterações do controle (passo de amostragem)
int16_t ciclo_util;      // Valor atual do ciclo de trabalho do PWM

int8_t RxBuffer[5];  // Buffer de recepção para armazenar os bytes recebidos via UART

int24_t ki_ventoinha = 2;      // Ganho do termo integral da ventoinha (1/1000)
int24_t kd_ventoinha = 10000;  // Ganho do termo derivativo da ventoinha
int24_t kp_ventoinha = 1300;   // Ganho do termo proporcional da ventoinha

int24_t ki_valvula = 1000;  // Ganho do termo integral da válvula
int24_t kp_valvula = 2950;  // Ganho do termo proporcional da válvula (antes 840)

int16_t tempo_medio = 0;   // Média dos últimos tempos medidos pelo sensor ultrassônico
int24_t altura_bola = 0;   // Última altura medida da bola

int16_t posicao_val_atual = 0;  // Posição atual da válvula
int16_t altura_desejada;        // Altura que o sistema deseja atingir
int16_t posicao_val_futura = 0; // Posição futura da válvula determinada pelo controle

int16_t ciclo_util_futuro = 0;  // Próximo valor do ciclo de trabalho da ventoinha determinado pelo controle

int8_t npassos = 0;  // Número de passos do motor de passos para controlar a válvula

int8_t dados_de_envio[15];  // Buffer de 15 bytes para envio de dados pela UART

uint8_t modo;  // Armazena o modo de operação do sistema (Manual, Ventoinha, Válvula, Reset)

bool dado_atual = false;     // Indica se os dados recebidos pela UART são recentes
bool ultima_medicao = false; // Indica se os dados da última medição do sensor estão atualizados

int8_t countRx = 0;  // Contador de bytes recebidos via UART



#ifdef	__cplusplus
}
#endif

#endif	/* MAIN_H */

